"""RAT test suite."""
